package com.mavenuser.bigburger.domain.model

data class Order(val id: Int,
                 val current_order: Int)
