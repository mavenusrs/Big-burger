package com.mavenuser.bigburger.data.local.entity

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(@PrimaryKey(autoGenerate = true) @ColumnInfo(index = true) val id: Int,
                       val current_order: Int)
