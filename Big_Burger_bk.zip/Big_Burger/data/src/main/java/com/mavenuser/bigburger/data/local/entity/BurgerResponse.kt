package com.mavenuser.bigburger.data.local.entity

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.ForeignKey
import android.arch.persistence.room.PrimaryKey


@Entity(tableName = "burgers",
    foreignKeys = arrayOf(ForeignKey(entity = OrderEntity::class,
    parentColumns = arrayOf("id"),
    childColumns = arrayOf("order_id"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE)
    ))
data class BurgerResponse (
    @PrimaryKey(autoGenerate = true) var id: Int,
    val ref: String,
    val title: String,
    val description: String,
    val thumbnail: String,
    val price: Double,
    var count: Int,
    @ColumnInfo(index = true) var order_id: String)