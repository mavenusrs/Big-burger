package com.mavenuser.bigburger.domain.repository

import com.mavenuser.bigburger.domain.model.Order
import io.reactivex.Completable
import io.reactivex.Single

interface OrderRepository {

    fun getCurrentOrder(): Single<Order>

    fun AddOrder(): Completable

    fun updateOrder(order: Order): Completable

    fun daleteOrder(order: Order): Completable
}