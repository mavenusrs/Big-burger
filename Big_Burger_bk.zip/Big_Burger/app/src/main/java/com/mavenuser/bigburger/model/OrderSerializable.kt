package com.mavenuser.bigburger.model

data class OrderSerializable(val id: Int,
                             val current_order: Int)
